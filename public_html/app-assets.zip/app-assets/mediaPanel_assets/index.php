<?php
$host = "http://".$_SERVER['HTTP_HOST']."/404";
header("location:".$host);
?>